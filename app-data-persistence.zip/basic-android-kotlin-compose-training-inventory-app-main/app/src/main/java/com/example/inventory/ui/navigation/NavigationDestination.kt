
package com.example.inventory.ui.navigation

interface NavigationDestination {

    val route: String

    val titleRes: Int
}
